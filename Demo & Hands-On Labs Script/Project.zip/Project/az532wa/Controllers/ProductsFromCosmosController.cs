﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using azure532Project.Models;

namespace azure532Project.Controllers
{
    [Authorize]
    public class ProductsFromCosmosController : Controller
    {
        // GET: ProductsFromCosmos
        [ActionName("Index")]
        public async Task<ActionResult> Index()
        {
            var items = await CosmosDbRepository<ProductsFromCosmos>.GetItemsAsync();
            return View(items);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ActionName("Create")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreateAsync([Bind(Include = "ProductID,Name,ProductModel,Culture,Description")] ProductsFromCosmos item)
        {
            if (ModelState.IsValid)
            {
                await CosmosDbRepository<ProductsFromCosmos>.CreateItemAsync(item);
                return RedirectToAction("Index");
            }
            return View(item);
        }

    }
}